#!/bin/sh
echo '{
  "name": "test",
  "methods": [
    "list"
  ]
}'